<?php $__env->startSection('title', 'Violation Logs'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Log of Violations</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead class="text-primary">
                                <th>ID</th>
                                <th>Name</th>
                                <th>Date</th>
                                <th>Description</th>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>1</td>
                                    <td>Adikara Rudi</td>
                                    <td>16 March 2020</td>
                                    <td>Hasn't presence out.</td>
                                </tr>
                                <tr>
                                    <td>7</td>
                                    <td>Vera Uyainah</td>
                                    <td>16 March 2020</td>
                                    <td>Hasn't presence out.</td>
                                </tr>
                                <tr>
                                    <td>16</td>
                                    <td>Gasti Yuliarti</td>
                                    <td>16 March 2020</td>
                                    <td>Hasn't presence out.</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Kuliah\Kerja Praktek (KP)\Project Absence\absence\resources\views/admin/violation_log.blade.php ENDPATH**/ ?>