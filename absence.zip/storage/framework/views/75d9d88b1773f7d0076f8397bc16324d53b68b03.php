<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="wrapper">
    <div class="landing-header" style="background-image: url('../img/background.png');">
        <div class="container tim-container">
            <div class="motto">
                <h1 class="title-uppercase mtom">Hello, </h1>
                <h3 class="mtop"> <?php echo e(Auth::user()->name); ?> !</h3>
            </div>
            <div class="row">
                <?php if(session('message')): ?>
                    <div class="alert alert-success alert-dismissable custom-success-box" style="margin: 15px;">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong> <?php echo e(session('message')); ?> </strong>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="main">
        <div class="section text-center landing-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2">
                        <h3>Choose Your Presence</h3>
                        <br>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="col-md-3 col-sm-12 mx-auto">
                        <img src="<?php echo e(asset('img/presin.png')); ?>" alt="Rounded Image" class="img-rounded img-responsive">
                        <br>
                        <a href="<?php echo e(url("user/presence/in")); ?>" class="btn btn-fill btn-info">Presence In</a>
                    </div>
                    <div class="col-md-3 col-sm-12">
                        <img src="<?php echo e(asset('img/presout.png')); ?>" alt="Rounded Image"
                            class="img-rounded img-responsive">
                        <br>
                        <a href="<?php echo e(url("user/presence/out")); ?>" class="btn btn-fill btn-info">Presence Out</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Kuliah\Kerja Praktek (KP)\Project Absence\absence\resources\views/user/dashboard.blade.php ENDPATH**/ ?>