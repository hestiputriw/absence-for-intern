<?php $__env->startSection('title', 'Presence Out'); ?>

<?php $__env->startSection('content'); ?>
    <?php echo QrCode::size(300)->generate($randomletter); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard_host', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Kuliah\Kerja Praktek (KP)\Project Absence\absence\resources\views/host/presence_out.blade.php ENDPATH**/ ?>