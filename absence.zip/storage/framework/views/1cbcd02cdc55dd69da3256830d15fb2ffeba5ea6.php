<?php $__env->startSection('title', 'Users Profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="wrapper">
    <div class="row row-profile">
        <div class="col-md-4 row-profile">
            <div class="profile-background">
                <div class="filter-black"></div>
                <div class="row">
                    <?php if(session('message')): ?>
                    <div class="alert alert-success alert-dismissable custom-success-box" style="margin: 15px;">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong> <?php echo e(session('message')); ?> </strong>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="profile-content">
                <div class="row owner-profile row-profile justify-content-center">
                    <div class="col-md-4 col-sm-4 col-xs-6 text-center">
                        <div class="avatar">
                            <img src="<?php echo e(asset('img/logo-small.png')); ?>" alt="Circle Image"
                                class="img-circle img-no-padding img-responsive">
                        </div>
                        <div class="name">
                            <h3><?php echo e(Auth::user()->name); ?><br /><small><i class="fa fa-university"></i>
                                    <?php echo e(Auth::user()->institute); ?></small></h3>
                        </div>
                    </div>
                </div>
                <div class="row row-profile justify-content-center">
                    <div class="col">
                        <a href="<?php echo e(url("user/profile")); ?>" class="btn btn-info btn-fill btn-block btn-top"><i
                                class="fa fa-user"></i> Profile</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-8 row-profile">
            <div class="container-profile">
                <div class="card card-profile">
                    <form class="register-form" action="<?php echo e(url('user/profile/update')); ?>" method="POST">
                        <?php echo method_field('patch'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-8">
                                <label>Name</label>
                                <input type="text" class="form-control color-text top" placeholder="Name"
                                    value="<?php echo e(Auth::user()->name); ?>" name="name">
                                <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span><br>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                            <div class="col-md-4">
                                <label>Username</label>
                                <input type="text" class="form-control color-text top" name="username"
                                    value="<?php echo e(Auth::user()->username); ?>" placeholder="Username">
                                <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span><br>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-5">
                                <label>Email</label>
                                <input type="text" class="form-control color-text top" value="<?php echo e(Auth::user()->email); ?>"
                                    name="email" placeholder="Email">
                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span><br>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                            <div class="col-md-3">
                                <label>Password</label>
                                <input type="password" class="form-control color-text top" placeholder="Password"
                                    value="" name="password">
                                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span><br>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                            <div class="col-md-4">
                                <label>Phone Number</label>
                                <input type="text" class="form-control color-text top" placeholder="Phone"
                                    value="<?php echo e(Auth::user()->phone); ?>" name="phone">
                                <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span><br>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                            </div>
                        </div>

                        <label>Institute</label>
                        <input type="text" class="form-control color-text top" placeholder="Institute"
                            value="<?php echo e(Auth::user()->institute); ?>" name="institute">
                        <?php if ($errors->has('institute')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('institute'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span><br>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                        <label>Address</label>
                        <textarea class="form-control color-text top" rows="3"
                            name="address"><?php echo e(Auth::user()->address); ?></textarea>
                        <?php if ($errors->has('address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span><br>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                        <button type="submit" class="btn btn-info btn-fill btn-block btn-top"><i
                                class="fa fa-pencil-square-o"></i> Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Kuliah\Kerja Praktek (KP)\Project Absence\absence\resources\views/user/profile_update.blade.php ENDPATH**/ ?>