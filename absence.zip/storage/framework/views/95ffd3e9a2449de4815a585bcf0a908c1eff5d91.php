<?php $__env->startSection('title','Register'); ?>

<?php $__env->startSection('content'); ?>   
    <div class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1 ">
        <div class="register-card">
            <h3 class="title">Welcome</h3>
            <form class="register-form" action="<?php echo e(url('register')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <label>Name</label>
                <input type="text" class="form-control color-text" placeholder="Name" id="name" name="name">
                <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span><br>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                <label>Username</label>
                <input type="text" class="form-control color-text" placeholder="Username" id="username" name="username">
                <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span><br>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                <label>Email</label>
                <input type="text" class="form-control color-text" placeholder="Email" id="email" name="email">
                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span><br>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                <label>Password</label>
                <input type="password" class="form-control color-text" placeholder="Password" id="password" name="password">
                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span><br>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                <label>Institute</label>
                <input type="text" class="form-control color-text" placeholder="Institute" id="institute" name="institute">
                <?php if ($errors->has('institute')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('institute'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span><br>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                <label>Address</label>
                <textarea class="form-control color-text" rows="3" id="address" name="address"></textarea>
                <?php if ($errors->has('address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span><br>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                <label>Phone Number</label>
                <input type="text" class="form-control color-text" placeholder="Phone" id="phone" name="phone">
                <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span><br>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                <button type="submit" class="btn btn-info btn-fill btn-block">Register</button>

                <div class="forgot">
                    <a href="<?php echo e(url("/")); ?>" class="btn btn-danger btn-fill btn-block">Login</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard_public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Kuliah\Kerja Praktek (KP)\Project Absence\absence\resources\views/public/register.blade.php ENDPATH**/ ?>