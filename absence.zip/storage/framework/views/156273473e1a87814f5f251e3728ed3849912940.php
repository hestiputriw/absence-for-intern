<?php $__env->startSection('title','Login'); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1 ">
    <div class="register-card">
        <h3 class="title">Welcome</h3>
        <form method="POST" action="/">
            <?php echo csrf_field(); ?>
            <label>Username</label>
            <input type=" text" class="form-control color-text" placeholder="username" id="username" name="username"
                value="<?php echo e(old('username')); ?>">
            <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            <br>

            <label>Password</label>
            <input type="password" class="form-control" placeholder="Password" id="password" name="password">
            <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            <button type="submit" class="btn btn-info btn-fill btn-block">Login</button>
        </form>
        <div class="forgot">
            <a href="<?php echo e(url("register")); ?>" class="btn btn-danger btn-fill btn-block">Register</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard_public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Kuliah\Kerja Praktek (KP)\Project Absence\absence\resources\views/public/login.blade.php ENDPATH**/ ?>