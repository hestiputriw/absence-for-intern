<?php $__env->startSection('title', 'Presence In'); ?>

<?php $__env->startSection('content'); ?>
<div class="wrapper">
    <div class="main">
        <div class="section text-center landing-section">
            <div class="container tim-container">
                <div class="row">
                    <?php if(session('message')): ?>
                    <div class="alert alert-success alert-dismissable custom-success-box" style="margin: 15px;">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong> <?php echo e(session('message')); ?> </strong>
                    </div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                    <div class="alert alert-primary" role="alert">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                    <div class="col-md-8 col-md-offset-2 text-center">
                        <h2>Scan QR Code</h2>
                    </div>
                </div>

                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="embed-responsive embed-responsive-16by9">
                                <video class="embed-responsive-item" id="preview"></video>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <form action="<?php echo e(url('user/presence/in')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="code" id="code">
        <button type="submit" hidden id="submit">Register</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript" src="https://rawgit.com/schmich/instascan-builds/master/instascan.min.js"></script>

<script type="text/javascript">
    let scanner = new Instascan.Scanner({ video: document.getElementById('preview') });
      scanner.addListener('scan', function (content) {
        $('#code').val(content)
        $('#submit').click()
      });
      Instascan.Camera.getCameras().then(function (cameras) {
        if (cameras.length > 0) {
          scanner.start(cameras[0]);
        } else {
          console.log('No cameras found.');
        }
      }).catch(function (e) {
        console.error(e);
      });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Kuliah\Kerja Praktek (KP)\Project Absence\absence\resources\views/user/presence_in.blade.php ENDPATH**/ ?>