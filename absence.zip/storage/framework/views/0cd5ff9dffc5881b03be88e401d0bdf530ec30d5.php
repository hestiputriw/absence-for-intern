<?php $__env->startSection('title', 'Users Profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="wrapper">
    <div class="profile-background"> 
        <div class="filter-black"></div>  
    </div>
    <div class="profile-content section-nude">
        <div class="container">
            <div class="row owner">
                <div class="col-md-2 col-md-offset-5 col-sm-4 col-sm-offset-4 col-xs-6 col-xs-offset-3 text-center">
                    <div class="avatar">
                        <img src="<?php echo e(asset('img/logo-small.png')); ?>" alt="Circle Image" class="img-circle img-no-padding img-responsive">
                    </div>
                    <div class="name">
                        <h3><?php echo e(Auth::user()->name); ?><br /><small><i class="fa fa-university"></i> <?php echo e(Auth::user()->institute); ?></small></h3>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col">
                    <a href="<?php echo e(url("user/profile/update/")); ?>" class="btn btn-info btn-fill btn-block btn-top"><i class="fa fa-pencil-square-o"></i> Update</a>
                </div>
            </div>     
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Kuliah\Kerja Praktek (KP)\Project Absence\absence\resources\views/user/profile.blade.php ENDPATH**/ ?>