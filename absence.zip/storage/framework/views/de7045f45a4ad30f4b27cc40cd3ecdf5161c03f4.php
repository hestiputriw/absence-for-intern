<?php $__env->startSection('title', 'Information of Presence'); ?>

<?php $__env->startSection('content'); ?>
<div class="wrapper">
    <div class="main section-light-gray">
        
        <div class="section text-center landing-section mt-md-4">
            <div class="container tim-container">
                <div class="row">
                    <div class="text-center">
                        <div class="col">
                            <p>
                                <?php echo e(Auth::user()->name); ?><br>
                                <i class="fa fa-university"></i> <?php echo e(Auth::user()->institute); ?>

                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        

        
        <div class="section text-center landing-section">
            <div class="container tim-container">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2 text-center">
                        <div class="card card-plain">
                            <div class="card-header">
                                <h4 class="card-title">Your Presence Record</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead class="text-primary">
                                            <th>#</th>
                                            <th>Presence In</th>
                                            <th>Presence Out</th>
                                        </thead>
                                        <tbody class="table-mar">
                                            <?php $__currentLoopData = $presences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $presence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($key+1); ?></td>
                                                <td><?php echo e($presence->time_in); ?></td>
                                                <td><?php echo e($presence->time_out); ?></td>
                                                
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Kuliah\Kerja Praktek (KP)\Project Absence\absence\resources\views/user/presence_info.blade.php ENDPATH**/ ?>